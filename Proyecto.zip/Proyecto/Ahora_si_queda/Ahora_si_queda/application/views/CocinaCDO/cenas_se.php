<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | Corlate</title>

    <!-- core CSS -->
    <link href="<?php echo base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/animate.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/owl.carousel.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/icomoon.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/main.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    <link rel="shortcut icon" href="<?php echo base_url(); ?>Assets/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url(); ?>Assets/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url(); ?>Assets/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url(); ?>Assets/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo base_url(); ?>Assets/images/ico/apple-touch-icon-57-precomposed.png">
</head>
<!--/head-->

<body>

   <header id="header">
        <div class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-xs-12">
                        <div class="top-number">
                            <!-- <p><i class="fa fa-phone-square"></i> +0123 456 70 90</p> -->
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <div class="social">
                              <ul class="social-share">
                                <li><a href="https://facebook.com"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://instagram.com"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="https://youtube.com"><i class="fa fa-youtube"></i></a></li>
                                
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.top-bar-->

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"><img src="<?php echo base_url(); ?>Assets/images/logo.png" alt="logo"></a>
                </div>

                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="Index_se">Inicio</a></li>
                         <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Recetas<i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="Desayunos_se">Desayuno</a></li>
                                <li><a href="Comidas_se">Comida</a></li>
                                <li><a href="Cenas_se">Cena</a></li>
                                <li><a href="Postres_se">Postres</a></li>
                            </ul>
                        </li>

                        <li><a href="Subir_receta">Subir Recetas</a></li>
                        <li><a href="Indexdos">Salir</a></li>


                    </ul>
                </div>
            </div>
            <!--/.container-->
        </nav>
        <!--/nav-->

    </header>
    <!--/header-->

    <div class="page-title" style="background-image: url(<?php echo base_url(); ?>Assets/images/fondos/fondocena.jpg)">
        <h1>CENAS</h1>
    </div>

 <section>
        <?php foreach ($datito as $p) {?>
        <div class="blog container">
            <div class="row">
                <div class="col-md-8">

                    <div 
                    class="blog-item">
                       <!--  <a href="#"><img class="img-responsive img-blog" src="images/blog1.png" width="100%" alt="" /></a>  --><!-- aqui va la imagen del platillo -->
                        <div class="blog-content" style="background-image: url(<?php echo base_url(); ?>Assets/images/fondo_rece.jpg)">
                            <h2><a href="blog-item.html"><?php echo $p->nombre_r?></a></h2>
                            <div class="post-meta">
                                <p><a href="#"><?php echo $p->autor_r ?></a></p>
                                <p><i class="fa fa-clock-o"></i> <a href="#"></a><?php echo $p->fecha_r ?></p>
                                <p>
                                    <!-- compartir -->
                                    share:
                                    <a href="#" class="fa fa-facebook"></a>
                                    <a href="#" class="fa fa-twitter"></a>

                                    
                                </p>
                            </div>
                            <h3><?php echo $p->resena ?></h3>
                            <br>


</div>
</div>
</div>
<?php } ?>
 <aside class="col-md-4" >

                    <div class="widget popular_post">
                        <h3>Otras Recetas</h3>
                        <ul>
                            <li>
                                <a href="Comidas_se">
                                    <img src="<?php echo base_url(); ?>Assets/images/comida_promo.jpg"  alt="">
                                    <p>Comidas deliciosas</p>
                                </a>
                            </li>
                            <li>
                                <a href="Postres_se">
                                    <img src="<?php echo base_url(); ?>Assets/images/postre_promo.jpg" alt="">
                                    <p>Momento del postre</p>
                                </a>
                            </li>
                            <li>
                                <a href="Desayunos_se">
                                    <img src="<?php echo base_url(); ?>Assets/images/desayuno_promo.jpg" alt="">
                                    <p>Algo bueno para iniciar</p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </aside>
</div>
</div>


</section>

 
        <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2019 <a target="_blank" href="http://shapebootstrap.net/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">Cocina Chido </a>Página en Desarrollo BETA 1.5
                </div>
                <div class="col-sm-6">
                    
                </div>
            </div>
        </div>
    </footer>
    <!--/#footer-->

    <script src="<?php echo base_url(); ?>Assets/js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/jquery.isotope.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/main.js"></script>
</body>

</html>
