<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | Corlate</title>

    <!-- core CSS -->
    <link href="<?php echo base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/animate.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/prettyPhoto.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/owl.carousel.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/icomoon.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/main.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>Assets/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
    <link rel="shortcut icon" href="<?php echo base_url(); ?>Assets/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url(); ?>Assets/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url(); ?>Assets/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url(); ?>Assets/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="<?php echo base_url(); ?>Assets/images/ico/apple-touch-icon-57-precomposed.png">
</head>
<!--/head-->

<body class="homepage">

    <header id="header">
        <div class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-xs-12">
                        <div class="top-number">
                            <!-- <p><i class="fa fa-phone-square"></i> +0123 456 70 90</p> -->
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <div class="social">
                           <ul class="social-share">
                                <li><a href="https://facebook.com"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://instagram.com"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="https://youtube.com"><i class="fa fa-youtube"></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.top-bar-->

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"><img src="<?php echo base_url(); ?>Assets/images/logo.png" alt="logo"></a>
                </div>

                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#">Inicio</a></li>
                         <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Recetas<i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="Desayunos_se">Desayuno</a></li>
                                <li><a href="Comidas_se">Comida</a></li>
                                <li><a href="Cenas_se">Cena</a></li>
                                <li><a href="Postres_se">Postres</a></li>
                            </ul>
                        </li>

                        <li><a href="Subir_receta">Subir Recetas</a></li>
                        <li><a href="Indexdos">Salir</a></li>


                    </ul>
                </div>
            </div>
            <!--/.container-->
        </nav>
        <!--/nav-->

    </header>
    <!--/header-->

    <section id="main-slider" class="no-margin">
        <div class="carousel slide">
            <ol class="carousel-indicators">
                <li data-target="#main-slider" data-slide-to="0" class="active"></li>
                <li data-target="#main-slider" data-slide-to="1"></li>
                <li data-target="#main-slider" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">

                <div class="item active" style="background-image: url(<?php echo base_url(); ?>Assets/images/slider/Inicio_Desayuno.jpg)">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">ALGO NUEVO AL DESPERTAR</h1>
                                    <div class="animation animated-item-2" >
                                        Conoce los desayunos mas ricos, creativos y geniales en nuestra seccion y prepra algo nuevo cada mañana
                                    </div>
                                    <a class="btn-slide animation animated-item-3" href="Desayunos_se">Ver Mas</a>
                                  
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!--/.item-->

                <div class="item" style="background-image: url(<?php echo base_url(); ?>Assets/images/slider/Inicio_Comida.jpg)">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">NUEVOS PLATILLOS PARA LA HORA DE COMER</h1>
                                    <div class="animation animated-item-2">
                                    Conoce los nuevos platillos y prepara el que mas te se te antoje
                                    </div>
                                    
                                    <a class="btn-slide animation animated-item-3" href="Comidas_se">Ver Mas</a>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <!--/.item-->
                <div class="item" style="background-image: url(<?php echo base_url(); ?>Assets/images/slider/Inicio_Postres.jpg)">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-7">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">LA HORA DEL POSTRE</h1>
                                    <div class="animation animated-item-2">
                                    Date gusto con estos increibles postres
                                    </div>
                                    
                                    <a class="btn-slide animation animated-item-3" href="Postres_se">Ver Mas</a>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <!--/.item-->

            </div>
            <!--/.carousel-inner-->
        </div>
        <!--/.carousel-->
        <a class="prev hidden-xs hidden-sm" href="#main-slider" data-slide="prev">
            <i class="fa fa-chevron-left"></i>
        </a>
        <a class="next hidden-xs hidden-sm" href="#main-slider" data-slide="next">
            <i class="fa fa-chevron-right"></i>
        </a>
    </section>

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2019 <a target="_blank" href="http://shapebootstrap.net/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">Cocina Chido </a>Página en Desarrollo BETA 1.5
                </div>
                <div class="col-sm-6">
                   
                </div>
            </div>
        </div>
    </footer>
    <!--/#footer-->

    <script src="<?php echo base_url(); ?>Assets/js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/jquery.isotope.min.js"></script>
    <script src="<?php echo base_url(); ?>Assets/js/main.js"></script>
</body>

</html>
