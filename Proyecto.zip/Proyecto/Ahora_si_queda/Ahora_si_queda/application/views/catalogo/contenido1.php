<nav>
		Menu
		<ul>
	 <li><a href="">Principal</a></li>
	  <li><a href="">Fotos</a></li>
	  <li><a href="">Videos</a></li>
	   <li><a href="">Contactos</a></li>
</ul>

	</nav>