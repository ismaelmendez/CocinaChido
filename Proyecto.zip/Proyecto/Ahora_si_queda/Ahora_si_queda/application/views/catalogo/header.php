<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Practica 2</title>

</head>
<body>
	<header>
		<h1>Cabecera</h1>
	</header>