<footer>
	<h2>Footer: Drechos reservados &copy;  2010-2011</h2>
</footer>
</body>
</html>