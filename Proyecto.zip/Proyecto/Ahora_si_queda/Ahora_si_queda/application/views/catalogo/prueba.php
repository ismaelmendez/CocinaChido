<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Practica 2</title>

</head>
<body>
	<header>
		<h1>Cabecera</h1>
	</header>
	<nav>
		Menu
		<ul>
	 <li><a href="">Principal</a></li>
	  <li><a href="">Fotos</a></li>
	  <li><a href="">Videos</a></li>
	   <li><a href="">Contactos</a></li>
</ul>

	</nav>
	<article>
		<h2>Noticias Article</h2> 
		<section>
			Section
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</section>
	</article>
<aside>
<h3>aside</h3>
</aside>
<footer>
	<h2>Footer: Drechos reservados &copy;  2010-2011</h2>
</footer>
</body>
</html>
