<article>
		<h2>Noticias Article</h2> 
		<section>
			La marca es <?php echo $marca;  ?>
	</section>
	</article>
<aside>
<h3>aside</h3>
</aside>