<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<!-- <table border="2">
	<tr>
		<th>ID</th>
		<th>Nombre</th>
		<th>Apellidos</th>
		<th>Edad</th>
	</tr>

	<?php foreach ($alumnos as $a) {?>
	<tr>
		<td><?php echo $a->ID ?></td>
		<td><?php echo $a->Nombre ?></td>
		<td><?php echo $a->Apellido ?></td>
		<td><?php echo $a->Edad ?></td>
	</tr>
	<?php } ?>
	</table> -->
	<?php foreach ($alumnos as $a) {?>
	<form action="http://localhost/CodeIgniter/catalogo/Borrar/25" method="post">
		<p>ID<input type="text" name="id" value=<?php echo $a->ID ?> readonly="readonly"><br></p>
		<p>Nombre<input type="text" name="nom" value=<?php echo $a->Nombre ?>><br></p>
		<p>Apellidos<input type="text" name="ap" value=<?php echo $a->Apellido ?>><br></p>
		<p>Edad<input type="text" name="ed" value=<?php echo $a->Edad ?>><br></p>
		<input type="submit" value="Borrar">
	</form>
	<?php } ?>
</body>
</html>