<?php
class Bd_proyecto extends CI_Model{
	
public function insertar($nombre_u,$correo_u,$password){
	$this->db->query("INSERT INTO usuarios VALUES(NULL,'$nombre_u','$correo_u','$password');");
 }

// public function login($correo_u,$password){
	
// 	$consulta=$this->db->query('SELECT * FROM usuarios WHERE correo_u='.$correo_u.' AND password='.$password.'');
//        	return $consulta->result();
// 	}

public function login($correo_u,$password){
	
	$this->db->where('coreo_u',$correo_u);
		$this->db->where('password',$password);

       	$q=$this->db->get('usuarios');
       	if($q->num_rows()>0){
       		return true;

       	}
       	else {
       	return false;
       	}
	
	}
public function insertar_receta($nombre_r,$tipo_r,$fecha_r,$autor_r,$resena,$receta_r){
	$this->db->query("INSERT INTO receta VALUES(NULL,'$nombre_r','$tipo_r','$fecha_r','$autor_r','$resena','$receta_r');");
 }

 public function consulta_comida(){
       	$consulta=$this->db->query('SELECT * FROM receta WHERE tipo_r LIKE "%Comida%"');
       	return $consulta->result();

}

public function consulta_usuario(){
              $consulta=$this->db->query('SELECT * FROM usuarios');
              return $consulta->result();


}

public function consulta_receta(){
              $consulta=$this->db->query('SELECT * FROM receta');
              return $consulta->result();


}




public function consulta_cena(){
       	$consulta=$this->db->query('SELECT * FROM receta WHERE tipo_r LIKE "%Cena%"');
       	return $consulta->result();


}
public function consulta_desayuno(){
       	$consulta=$this->db->query('SELECT * FROM receta WHERE tipo_r LIKE "%Desayuno%"');
       	return $consulta->result();


}
public function consulta_postre(){
       	$consulta=$this->db->query('SELECT * FROM receta WHERE tipo_r LIKE "%Postre%"');
       	return $consulta->result();


}


public function eliminar_usuario($idd){
       $this->db->query("DELETE FROM usuarios WHERE id_u= '$idd' ");
              $consulta=$this->db->query('SELECT * FROM usuarios');
              return $consulta->result();
 }


 public function editar_us($nombre_u,$correo_u,$idd){
       $this->db->query("UPDATE usuarios SET nombre_u='$nombre_u', coreo_u='$correo_u' WHERE id_u=$idd");
              $consulta=$this->db->query('SELECT * FROM usuarios');
              return $consulta->result();
 }
 public function  eliminar_rec($idd){
       $this->db->query("DELETE FROM receta WHERE id_r= '$idd' ");
              $consulta=$this->db->query('SELECT * FROM receta');
              return $consulta->result();
 }

 public function editar_rec($nombre_r,$receta_r,$idd){
       $this->db->query("UPDATE receta SET nombre_r='$nombre_r', receta_r='$receta_r' WHERE id_r=$idd");
              $consulta=$this->db->query('SELECT * FROM receta');
              return $consulta->result();
 }





}

?>