<?php
class Alumnos extends CI_Model{
	public function Consulta(){
		$consulta = $this->db->query('Select * from alumnos');
		return $consulta->result();
	}
	// public function ConsultaPar($id){

	// 	$consulta = $this->db->query('Select * from alumnos where ID = '.$id.'');
	// 	return $consulta->result();
	// }

	public function ConsultaPar($id){
		$this->db->select('*');
		$this->db->where('id='.$id.'');
		$resultado = $this->db->get('alumnos');
		return $resultado->result();
	}

	public function Insertar($datos){
		$this->db->insert('alumnos', $datos);
		echo 'Datos insertados';
		$this->db->select('*');
		$resultado = $this->db->get('alumnos');
		return $resultado->result();
	}

	public function Upd($id, $datos){
		$this->db->where('id', $id);
		$this->db->update('alumnos', $datos);
		echo 'Actualizado';
		$this->db->select('*');
		$this->db->where('id='.$id.'');
		$resultado = $this->db->get('alumnos');
		return $resultado->result();
	}

	public function Del($id){
		$this->db->where('id', $id);
		$this->db->delete('alumnos');
		echo 'Eliminado';
		
	}
}


?>