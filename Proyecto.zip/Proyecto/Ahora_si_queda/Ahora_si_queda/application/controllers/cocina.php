<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cocina extends CI_Controller{


public function Index(){

	$this->load->view('CocinaCDO/index');
	}

	public function Desayunos(){

     $this->load->model('bd_proyecto');
     $data=array('datito'=> $this->bd_proyecto->consulta_desayuno());
	  $this->load->view('CocinaCDO/desayunos',$data);
	}
	
	public function Comidas(){
	$this->load->model('bd_proyecto');
     $data=array('datito'=> $this->bd_proyecto->consulta_comida());



	$this->load->view('CocinaCDO/comidas',$data);
	}

	public function Cenas(){
	$this->load->model('bd_proyecto');
     $data=array('datito'=> $this->bd_proyecto->consulta_cena());


	$this->load->view('CocinaCDO/cenas',$data);
	}
	public function Postres(){
	$this->load->model('bd_proyecto');
     $data=array('datito'=> $this->bd_proyecto->consulta_postre());


	$this->load->view('CocinaCDO/postres',$data);
	}

	public function Indexdos(){

	$this->load->view('CocinaCDO/index_dos');
	}

	public function Index_admi(){

		$this->load->view('CocinaCDO/index_admin');
	}

	public function Registrate(){

	$this->load->view('CocinaCDO/registrate');

	}
	public function Index_se(){

	$this->load->view('CocinaCDO/index_sesion');
	}

	public function Registrar_BD(){

       $nombre_u=$_POST["nombree"];
       $correo_u=$_POST["mail"];	
       $password=$_POST["pass"];

       $this->load->model('bd_proyecto');
       $this->bd_proyecto->insertar($nombre_u,$correo_u,$password);

       $this->load->view('CocinaCDO/index_sesion');
   

	}


	public function Loginn(){
		
		if(isset($_POST['pass'])){


		$this->load->model('bd_proyecto');

		if($this->bd_proyecto->login($_POST['mail'],$_POST['pass'])){
            
            redirect('cocina/Index_se');

		}
		else{


           redirect('cocina/Loginn'); 
		}
     

     } 
     $this->load->view('CocinaCDO/iniciar_sesion'); 
	}

	public function Subir_receta(){
		 $this->load->view('CocinaCDO/subir_recetas'); 
	}

	public function Subir_receta_BD(){



       $nombre_r=$_POST["nop"];
       $tipo_r=$_POST["tipoo"];	
       $fecha_r=$_POST["fech"];
       $autor_r=$_POST["autor"];
       $resena=$_POST["rese"];
       $receta_r=$_POST["receta"];

       $this->load->model('bd_proyecto');
       $this->bd_proyecto->insertar_receta($nombre_r,$tipo_r,$fecha_r,$autor_r,$resena,$receta_r);

       $this->load->view('CocinaCDO/subir_recetas');
   

	}


	public function Desayunos_se(){

     $this->load->model('bd_proyecto');
     $data=array('datito'=> $this->bd_proyecto->consulta_desayuno());
	  $this->load->view('CocinaCDO/desayunos_se',$data);
	}
	
	public function Comidas_se(){
	$this->load->model('bd_proyecto');
     $data=array('datito'=> $this->bd_proyecto->consulta_comida());



	$this->load->view('CocinaCDO/comidas_se',$data);
	}

	public function Cenas_se(){
	$this->load->model('bd_proyecto');
     $data=array('datito'=> $this->bd_proyecto->consulta_cena());


	$this->load->view('CocinaCDO/cenas_se',$data);
	}
	public function Postres_se(){
	$this->load->model('bd_proyecto');
     $data=array('datito'=> $this->bd_proyecto->consulta_postre());


	$this->load->view('CocinaCDO/postres_se',$data);
	}


	public function Eliminar_us(){
	$this->load->model('bd_proyecto');
    $data=array('datito'=> $this->bd_proyecto->consulta_usuario());
	$this->load->view('CocinaCDO/eliminar_usuario',$data);
	
	}
	public function Editaar_us(){
	$this->load->model('bd_proyecto');
    $data=array('datito'=> $this->bd_proyecto->consulta_usuario());
	$this->load->view('CocinaCDO/editar_usuario',$data);
	
	}

	public function Borrar_us(){
      $idd=$_POST["numero"];
      $this->load->model('bd_proyecto');
      $data=array('datito'=>$this->bd_proyecto->eliminar_usuario($idd));
      $this->load->view('CocinaCDO/eliminar_usuario',$data);

      }

      public function Editar_uss(){

       $nombre_u=$_POST["nombree"];
       $correo_u=$_POST["mail"];
       $idd=$_POST["numero"];

$this->load->model('bd_proyecto');
$data=array('datito'=>$this->bd_proyecto->editar_us($nombre_u, $correo_u,$idd));
$this->load->view('CocinaCDO/editar_usuario',$data);

}

public function Eliminar_re(){
	$this->load->model('bd_proyecto');
    $data=array('datito'=> $this->bd_proyecto->consulta_receta());
	$this->load->view('CocinaCDO/eliminar_receta',$data);
	
	}

	public function Borrar_re(){
      $idd=$_POST["numero"];
      $this->load->model('bd_proyecto');
      $data=array('datito'=>$this->bd_proyecto->eliminar_rec($idd));
      $this->load->view('CocinaCDO/eliminar_receta',$data);
      }

      	public function Editaar_receta(){
	$this->load->model('bd_proyecto');
    $data=array('datito'=> $this->bd_proyecto->consulta_receta());
	$this->load->view('CocinaCDO/editar_receta',$data);
	
	}



  public function Editar_rec(){

       $nombre_r=$_POST["nombree"];
       $receta_r=$_POST["receta"];
       $idd=$_POST["numero"];

$this->load->model('bd_proyecto');
$data=array('datito'=>$this->bd_proyecto->editar_rec($nombre_r, $receta_r,$idd));
$this->load->view('CocinaCDO/editar_receta',$data);

}






	





	

	public function Soporte(){
		
		if(isset($_POST['pass'])){
		$password=$_POST["pass"];
		$mail=$_POST['mail'];
		$valm='admin@cocinachido.com';
		$val=12345;
//  

		if($mail==$valm &&  $password==$val){
            
            redirect('cocina/Index_admi');

		}
		else{


           redirect('cocina/Soporte'); 
		}
     

     } 
     $this->load->view('CocinaCDO/Index_sesionadmin'); 
	}


	










}
?>