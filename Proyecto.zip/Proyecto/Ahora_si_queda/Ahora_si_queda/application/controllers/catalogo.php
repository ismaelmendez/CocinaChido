<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class catalogo extends CI_controller{
public function index(){
$this->load->view('catalogo/header.php');
$this->load->view('catalogo/contenido1.php');
$this->load->view('catalogo/contenido2.php');
$this->load->view('catalogo/footer.php');
}

public function Saludo(){
echo "Bienvenido";
}

public function ordenadores(){
echo "Página de ordenadores";
}

public function monitores($marca){
	$dato['marca']=$marca;
$this->load->view('catalogo/header');
$this->load->view('catalogo/contenido1');
$this->load->view('catalogo/contenido2',$dato);
$this->load->view('catalogo/footer');
}

public function perifericos(){
$this->load->view('catalogo/prueba.php');
}

public function CETES (){
$this->load->model('alumnos');
$data = array('alumnos'=>$this->alumnos->Consulta());
$this->load->view('VistaP11', $data);
}

public function Inser($nom, $ap, $ed){
$this->load->model('alumnos');
$d = array(
'Nombre' => $nom,
'Apellido' => $ap,
'Edad' => $ed
);
$datos = array('alumnos'=>$this->alumnos->Insertar($d));
$this->load->view('VistaP11', $datos);
}

public function Borrar($num){
	$this->load->model('alumnos');
	$datos = array('alumnos'=>$this->alumnos->ConsultaPar($num));
	// $this->load->view('Borrar', $datos);
	$datos = array('alumnos'=>$this->alumnos->Del($num));
}

public function Actualizar($id, $nom, $ap, $ed){
	$this->load->model('alumnos');
	$d = array(
	'Nombre' => $nom,
	'Apellido' => $ap,
	'Edad' => $ed
	);
	$datos = array('alumnos'=>$this->alumnos->Upd($id, $d));
	$this->load->view('VistaP11', $datos);
}
}
?>
