$(document).on('submit', '#guardar', function(e)
{
	var id = this.id;
	e.preventDefault();
	$.ajax({
		method: this.method,
		url: this.action,
		data: $(this).serialize(),
		dataType: 'json',
		success:function(data)
		{
			if(data['error'])
			{				
				var mensajes = data['mensaje'].split('</p>');
				console.log(mensajes);
				for (var i = 0; i <= mensajes.length - 2; i++) {
					Materialize.toast(mensajes[i], 2000);
				}
			}
			else
			{
				Materialize.toast(data['mensaje'], 2000);
				document.getElementById(id).reset();
			}
		}
	});
}); 


$(document).on('submit', '#sesion', function(e)
{
	var id = this.id;
	e.preventDefault();
	$.ajax({
		method: this.method,
		url: this.action,
		data: $(this).serialize(),
		dataType: 'json',
		success:function(data)
		{
			if(data['error'])
			{
				var mensajes = data['mensaje'].split(".");
				for(i = 0; i< mensajes.length - 1; i++)
				{
					Materialize.toast(mensajes[i], 2000);
				}
			}
			else
			{				
				Materialize.toast(data['mensaje'], 2000);
				location.reload();
			}
			
		}
	});
}); 
